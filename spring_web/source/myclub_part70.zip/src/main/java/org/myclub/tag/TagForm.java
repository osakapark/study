package org.myclub.tag;

import lombok.Data;

@Data
public class TagForm {

	private String tagTitle;

}
