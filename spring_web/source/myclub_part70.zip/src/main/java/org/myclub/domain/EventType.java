package org.myclub.domain;

public enum EventType {

	FCFS, CONFIRMATIVE;

}
