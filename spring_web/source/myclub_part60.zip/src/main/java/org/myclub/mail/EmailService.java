package org.myclub.mail;

public interface EmailService {

    void sendEmail(EmailMessage emailMessage);
}
