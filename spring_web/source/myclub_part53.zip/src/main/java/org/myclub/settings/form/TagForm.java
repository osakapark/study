package org.myclub.settings.form;

import lombok.Data;

@Data
public class TagForm {

    private String tagTitle;

}
