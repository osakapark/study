package org.myclub.domain;

import lombok.*;

import javax.persistence.*;

import org.myclub.account.UserAccount;

import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

//@formatter:off
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = "id")
@Builder
@AllArgsConstructor
@NoArgsConstructor
@NamedEntityGraph(name = "Study.withAll", attributeNodes = {
        @NamedAttributeNode("tags"),
        @NamedAttributeNode("zones"),
        @NamedAttributeNode("managers"),
        @NamedAttributeNode("members")})
//@formatter:on
public class Study {

	@Id
	@GeneratedValue
	private Long id;

	@Builder.Default
	@ManyToMany
	private Set<Account> managers = new HashSet<>();

	@Builder.Default
	@ManyToMany
	private Set<Account> members = new HashSet<>();

	@Column(unique = true)
	private String path;

	private String title;

	private String shortDescription;

	@Lob
	@Basic(fetch = FetchType.EAGER)
	private String fullDescription;

	@Lob
	@Basic(fetch = FetchType.EAGER)
	private String image;

	@Builder.Default
	@ManyToMany
	private Set<Tag> tags = new HashSet<>();

	@Builder.Default
	@ManyToMany
	private Set<Zone> zones = new HashSet<>();

	private LocalDateTime publishedDateTime;

	private LocalDateTime closedDateTime;

	private LocalDateTime recruitingUpdatedDateTime;

	private boolean recruiting;

	private boolean published;

	private boolean closed;

	private boolean useBanner;

	public void addManager(Account account) {
		this.managers.add(account);
	}

	public boolean isJoinable(UserAccount userAccount) {
		Account account = userAccount.getAccount();
		return this.isPublished() && this.isRecruiting() && !this.members.contains(account)
				&& !this.managers.contains(account);
	}

	public boolean isMember(UserAccount userAccount) {
		return this.members.contains(userAccount.getAccount());
	}

	public boolean isManager(UserAccount userAccount) {
		return this.managers.contains(userAccount.getAccount());
	}

	public void addMemeber(Account account) {
		this.members.add(account);
	}
}
